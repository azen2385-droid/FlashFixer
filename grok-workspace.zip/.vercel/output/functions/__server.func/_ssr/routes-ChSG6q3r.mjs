import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as CheckboxIndicator, t as Checkbox } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as Download, i as RefreshCw, o as Check, r as ShieldAlert, t as Usb } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ChSG6q3r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LANGS = [
	{
		id: "ar",
		label: "عربي"
	},
	{
		id: "en",
		label: "EN"
	},
	{
		id: "zh",
		label: "中文"
	},
	{
		id: "fr",
		label: "FR"
	}
];
var copy = {
	ar: {
		"app.title": "مصلح الفلاشات",
		"list.none": "مفيش فلاشات USB",
		"list.refresh": "تحديث",
		"list.count": "{0} فلاشة USB",
		"btn.repair": "فحص وإصلاح",
		"col.num": "القرص",
		"col.name": "الاسم",
		"col.size": "الحجم",
		"col.vidpid": "VID:PID",
		"col.status": "الحالة",
		"status.ready": "جاهز",
		"status.scanning": "جاري الفحص...",
		"warning.usb_all": "تحذير مهم: أي جهاز متوصل بـ USB هيظهر هنا (بما فيه الهاردات الخارجية). افصل أي هارد ديسك خارجي مش عايز تمسحه.",
		"confirm.title": "تأكيد الإصلاح",
		"confirm.warning": "كل البيانات على القرص ده هتتمسح.",
		"confirm.disk": "القرص: {0}",
		"confirm.name": "الاسم: {0}",
		"confirm.size": "الحجم: {0} ميجا",
		"confirm.vidpid": "VID:PID: {0}",
		"confirm.fp": "البصمة: {0}",
		"confirm.checkbox": "أنا فاهم إن كل البيانات على القرص ده هتضيع",
		"confirm.typetext": "اكتب \"{0}\" للتأكيد:",
		"confirm.proceed": "امسح وأصلح",
		"confirm.no": "إلغاء",
		"refuse.no_media": "مرفوض: مفيش وسيط",
		"warn.large": "تحذير: القرص أكبر من 256 جيجا. محتاج تأكيد إضافي.",
		"worker.done": "الإصلاح خلص بنجاح.",
		"uac.cancelled": "صلاحية المدير اترفضت.",
		"preview.banner": "معاينة للشكل بس. المتصفح مش شايف فلاشاتك، ومفيش أي مسح بيحصل من هنا.",
		"preview.sim": "أقراص تجريبية عشان تراجع الشاشة قبل ما تبني البرنامج على ويندوز.",
		"preview.download": "تنزيل كود برنامج الويندوز",
		"preview.compat": "النسخة الحقيقية: ملف واحد من ويندوز 7 SP1 لحد 11، 32 و 64 بت، من غير تثبيت. لازم .NET Framework 4.8.",
		"preview.xp": "ويندوز XP مش مدعوم. أدوات حماية قرص النظام وكشف الـ USB مش موجودة عليه، فنسخة أضعف تبقى خطر.",
		"preview.confirm_note": "الكتابة هنا تجربة للشاشة. مش هتتمسح أي حاجة.",
		"preview.uac_title": "صلاحية المدير",
		"preview.uac_body": "على الويندوز بتظهر نافذة UAC هنا. الزرارين دول تجريبيين.",
		"preview.allow": "موافقة",
		"preview.deny": "رفض",
		"preview.result_title": "المعاينة خلصت",
		"preview.result_body": "مفيش أي بيانات اتمسحت. في البرنامج الحقيقي، بعد التأكيد ده، diskpart هو اللي بيمسح الفلاشة اللي اتأكدنا من بصمتها.",
		"preview.real_says": "البرنامج الحقيقي هيقول:",
		"preview.close": "تمام"
	},
	en: {
		"app.title": "Flash Fixer",
		"list.none": "No USB flash drives found",
		"list.refresh": "Refresh",
		"list.count": "{0} USB disk(s)",
		"btn.repair": "Scan & Repair",
		"col.num": "Disk",
		"col.name": "Name",
		"col.size": "Size",
		"col.vidpid": "VID:PID",
		"col.status": "Status",
		"status.ready": "Ready",
		"status.scanning": "Scanning...",
		"warning.usb_all": "WARNING: Any USB-connected drive will appear here (including external HDDs). Disconnect any external hard drive you do not want to risk erasing.",
		"confirm.title": "Confirm Repair",
		"confirm.warning": "ALL DATA on this drive will be erased.",
		"confirm.disk": "Disk: {0}",
		"confirm.name": "Name: {0}",
		"confirm.size": "Size: {0} MB",
		"confirm.vidpid": "VID:PID: {0}",
		"confirm.fp": "Fingerprint: {0}",
		"confirm.checkbox": "I understand that all data on this drive will be lost",
		"confirm.typetext": "Type \"{0}\" to confirm:",
		"confirm.proceed": "Erase and repair",
		"confirm.no": "Cancel",
		"refuse.no_media": "Refused: No media",
		"warn.large": "Warning: disk larger than 256 GB. Extra confirmation required.",
		"worker.done": "Repair completed successfully.",
		"uac.cancelled": "Administrator permission was declined.",
		"preview.banner": "Layout preview only. This browser cannot see your drives, and nothing is erased here.",
		"preview.sim": "Sample disks, so you can review the screen before building the Windows program.",
		"preview.download": "Download the Windows source",
		"preview.compat": "The real build is one EXE for Windows 7 SP1 through 11, 32 and 64-bit, with no installer. It needs .NET Framework 4.8.",
		"preview.xp": "Windows XP is not supported. The system-disk guard and USB bus check do not exist there, so a weaker build would be a risk.",
		"preview.confirm_note": "Typing here only tests the screen. Nothing will be erased.",
		"preview.uac_title": "Administrator permission",
		"preview.uac_body": "On Windows, UAC appears here. These two buttons are only a preview.",
		"preview.allow": "Allow",
		"preview.deny": "Deny",
		"preview.result_title": "Preview finished",
		"preview.result_body": "No data was erased. In the real program, diskpart wipes only the drive whose fingerprint was just checked.",
		"preview.real_says": "The real program would say:",
		"preview.close": "Done"
	},
	zh: {
		"app.title": "U盘修复工具",
		"list.none": "未找到 USB 闪存盘",
		"list.refresh": "刷新",
		"list.count": "{0} 个 USB 磁盘",
		"btn.repair": "扫描并修复",
		"col.num": "磁盘",
		"col.name": "名称",
		"col.size": "大小",
		"col.vidpid": "VID:PID",
		"col.status": "状态",
		"status.ready": "就绪",
		"status.scanning": "正在扫描...",
		"warning.usb_all": "警告：所有通过 USB 连接的磁盘都会显示在此（包括外接硬盘）。请先断开您不希望被擦除的外接硬盘。",
		"confirm.title": "确认修复",
		"confirm.warning": "此驱动器上的所有数据将被擦除。",
		"confirm.disk": "磁盘：{0}",
		"confirm.name": "名称：{0}",
		"confirm.size": "大小：{0} MB",
		"confirm.vidpid": "VID:PID：{0}",
		"confirm.fp": "指纹：{0}",
		"confirm.checkbox": "我明白此驱动器上的所有数据都将丢失",
		"confirm.typetext": "输入\"{0}\"以确认：",
		"confirm.proceed": "擦除并修复",
		"confirm.no": "取消",
		"refuse.no_media": "已拒绝：无介质",
		"warn.large": "警告：磁盘大于 256 GB。需要额外确认。",
		"worker.done": "修复成功完成。",
		"uac.cancelled": "管理员权限被拒绝。",
		"preview.banner": "这只是界面预览。浏览器看不到您的磁盘，这里不会擦除任何数据。",
		"preview.sim": "以下是示例磁盘，方便您在 Windows 上编译前先看屏幕。",
		"preview.download": "下载 Windows 源码",
		"preview.compat": "正式版是一个 EXE，支持 Windows 7 SP1 到 11（32 位和 64 位），无需安装。需要 .NET Framework 4.8。",
		"preview.xp": "不支持 Windows XP。系统盘保护和 USB 总线检测在 XP 上不存在，弱化版本会有风险。",
		"preview.confirm_note": "在这里输入只是在试界面，不会擦除任何内容。",
		"preview.uac_title": "管理员权限",
		"preview.uac_body": "在 Windows 上，这里会弹出 UAC。这两个按钮只是预览。",
		"preview.allow": "允许",
		"preview.deny": "拒绝",
		"preview.result_title": "预览结束",
		"preview.result_body": "没有擦除任何数据。真正的程序会用 diskpart，并且只处理刚刚核对过指纹的那块盘。",
		"preview.real_says": "正式程序会显示：",
		"preview.close": "完成"
	},
	fr: {
		"app.title": "Réparateur de clés USB",
		"list.none": "Aucune clé USB trouvée",
		"list.refresh": "Rafraîchir",
		"list.count": "{0} disque(s) USB",
		"btn.repair": "Analyser et réparer",
		"col.num": "Disque",
		"col.name": "Nom",
		"col.size": "Taille",
		"col.vidpid": "VID:PID",
		"col.status": "État",
		"status.ready": "Prêt",
		"status.scanning": "Analyse...",
		"warning.usb_all": "AVERTISSEMENT : tout disque connecté en USB apparaîtra ici (y compris les disques externes). Débranchez tout disque externe que vous ne voulez pas risquer d'effacer.",
		"confirm.title": "Confirmer la réparation",
		"confirm.warning": "TOUTES LES DONNÉES de ce disque seront effacées.",
		"confirm.disk": "Disque : {0}",
		"confirm.name": "Nom : {0}",
		"confirm.size": "Taille : {0} Mo",
		"confirm.vidpid": "VID:PID : {0}",
		"confirm.fp": "Empreinte : {0}",
		"confirm.checkbox": "Je comprends que toutes les données de ce disque seront perdues",
		"confirm.typetext": "Tapez « {0} » pour confirmer :",
		"confirm.proceed": "Effacer et réparer",
		"confirm.no": "Annuler",
		"refuse.no_media": "Refusé : aucun média",
		"warn.large": "Attention : disque supérieur à 256 Go. Confirmation supplémentaire requise.",
		"worker.done": "Réparation terminée avec succès.",
		"uac.cancelled": "Autorisation administrateur refusée.",
		"preview.banner": "Aperçu seulement. Le navigateur ne voit pas vos disques, et rien n'est effacé ici.",
		"preview.sim": "Disques d'exemple, pour relire l'écran avant de compiler le programme Windows.",
		"preview.download": "Télécharger le code Windows",
		"preview.compat": "La vraie version est un EXE pour Windows 7 SP1 à 11, 32 et 64 bits, sans installation. .NET Framework 4.8 est requis.",
		"preview.xp": "Windows XP n'est pas pris en charge. La protection du disque système et le contrôle USB n'y existent pas.",
		"preview.confirm_note": "La saisie ici ne fait que tester l'écran. Rien ne sera effacé.",
		"preview.uac_title": "Autorisation administrateur",
		"preview.uac_body": "Sous Windows, l'UAC s'affiche ici. Ces deux boutons sont une prévisualisation.",
		"preview.allow": "Autoriser",
		"preview.deny": "Refuser",
		"preview.result_title": "Aperçu terminé",
		"preview.result_body": "Aucune donnée n'a été effacée. Le vrai programme lance diskpart uniquement sur le disque dont l'empreinte vient d'être vérifiée.",
		"preview.real_says": "Le vrai programme afficherait :",
		"preview.close": "Fermer"
	}
};
function t(lang, key, ...args) {
	let s = copy[lang][key] ?? copy.en[key] ?? key;
	args.forEach((arg, i) => {
		s = s.split(`{${i}}`).join(String(arg));
	});
	return s;
}
var DEMO_DISKS = [
	{
		number: 2,
		name: "Kingston DataTraveler 3.0",
		size: 15548024832,
		vid: "0951",
		pid: "1666"
	},
	{
		number: 4,
		name: "SanDisk Ultra",
		size: 61847529062,
		vid: "0781",
		pid: "5581"
	},
	{
		number: 5,
		name: "Seagate Expansion",
		size: 4000787030016,
		vid: "0BC2",
		pid: "231A"
	},
	{
		number: 6,
		name: "Generic Card Reader",
		size: 0,
		vid: "058F",
		pid: "6366"
	}
];
var LARGE = 274877906944;
function verdict(disk) {
	if (disk.size <= 0) return "refused";
	if (disk.size > LARGE) return "large";
	return "ok";
}
function statusKey(disk) {
	const v = verdict(disk);
	if (v === "refused") return "refuse.no_media";
	if (v === "large") return "warn.large";
	return "status.ready";
}
async function fingerprint(disk) {
	const raw = `${disk.size}|${disk.vid}:${disk.pid}`;
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
	const bytes = new Uint8Array(digest).slice(0, 8);
	return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
}
function Home() {
	const [lang, setLang] = (0, import_react.useState)("ar");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [phase, setPhase] = (0, import_react.useState)("list");
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [checked, setChecked] = (0, import_react.useState)(false);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [prints, setPrints] = (0, import_react.useState)({});
	const rtl = lang === "ar";
	const disk = DEMO_DISKS.find((d) => d.number === selected) ?? null;
	const canRepair = disk != null && verdict(disk) !== "refused";
	const label = disk ? `PhysicalDrive${disk.number}` : "";
	const confirmReady = checked && typed.trim() === label;
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		Promise.all(DEMO_DISKS.map(async (d) => [d.number, await fingerprint(d)])).then((rows) => {
			if (cancelled) return;
			const next = {};
			for (const [n, fp] of rows) next[n] = fp;
			setPrints(next);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	function refresh() {
		setScanning(true);
		setSelected(null);
		window.setTimeout(() => setScanning(false), 700);
	}
	function openRepair() {
		if (!canRepair) return;
		setChecked(false);
		setTyped("");
		setPhase("confirm");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		dir: rtl ? "rtl" : "ltr",
		lang,
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "bg-danger px-4 py-3 text-center text-sm font-semibold text-danger-ink",
				children: t(lang, "preview.banner")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-lg bg-danger text-danger-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Usb, { "aria-hidden": "true" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-bold leading-tight",
								children: t(lang, "app.title")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: LANGS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "lang-btn",
								"aria-pressed": lang === item.id,
								onClick: () => setLang(item.id),
								children: item.label
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "panel overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "bg-danger px-4 py-3 text-sm font-semibold text-danger-ink",
								children: t(lang, "warning.usb_all")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2 p-3 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "btn",
									onClick: refresh,
									disabled: scanning,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
										"aria-hidden": "true",
										size: 18
									}), t(lang, "list.refresh")]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "btn btn-danger",
									"data-testid": "repair",
									disabled: !canRepair || scanning,
									onClick: openRepair,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
										"aria-hidden": "true",
										size: 18
									}), t(lang, "btn.repair")]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-4 pb-2 text-sm text-muted",
								children: t(lang, "preview.sim")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden grid-cols-5 gap-2 px-4 pb-2 text-xs font-semibold text-muted sm:grid",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "col.num") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "col.name") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "col.size") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "col.vidpid") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "col.status") })
								]
							}),
							scanning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-4 py-8 text-muted",
								children: t(lang, "status.scanning")
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: DEMO_DISKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiskRow, {
								lang,
								disk: item,
								fp: prints[item.number] ?? "…",
								pressed: selected === item.number,
								onSelect: () => setSelected(item.number)
							}, item.number)) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border-t border-line px-4 py-3 text-sm text-muted",
								children: scanning ? t(lang, "status.scanning") : t(lang, "list.count", DEMO_DISKS.length)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "panel flex flex-col gap-3 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: t(lang, "preview.compat")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-warn",
								children: t(lang, "preview.xp")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "btn w-full sm:w-fit",
								href: "/FlashFixer-src.zip",
								download: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									"aria-hidden": "true",
									size: 18
								}), t(lang, "preview.download")]
							})
						]
					})
				]
			}),
			phase !== "list" && disk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 flex items-end justify-center bg-bg/80 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "dialog-title",
					className: "panel max-h-[92vh] w-full max-w-lg overflow-y-auto",
					children: [
						phase === "confirm" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
							lang,
							disk,
							fp: prints[disk.number] ?? "…",
							checked,
							typed,
							ready: confirmReady,
							onChecked: setChecked,
							onTyped: setTyped,
							onCancel: () => setPhase("list"),
							onOk: () => setPhase("uac")
						}) : null,
						phase === "uac" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "dialog-title",
									className: "text-xl font-bold",
									children: t(lang, "preview.uac_title")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(lang, "preview.uac_body")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn btn-danger",
										"data-testid": "uac-allow",
										onClick: () => setPhase("done"),
										children: t(lang, "preview.allow")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn",
										"data-testid": "uac-deny",
										onClick: () => setPhase("denied"),
										children: t(lang, "preview.deny")
									})]
								})
							]
						}) : null,
						phase === "done" || phase === "denied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "dialog-title",
									className: "text-xl font-bold",
									children: phase === "done" ? t(lang, "preview.result_title") : t(lang, "uac.cancelled")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed",
									children: phase === "done" ? t(lang, "preview.result_body") : t(lang, "preview.banner")
								}),
								phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "panel bg-surface-2 px-3 py-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-muted",
										children: t(lang, "preview.real_says")
									}), t(lang, "worker.done")]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn",
									onClick: () => setPhase("list"),
									children: t(lang, "preview.close")
								})
							]
						}) : null
					]
				})
			}) : null
		]
	});
}
function DiskRow({ lang, disk, fp, pressed, onSelect }) {
	const refused = verdict(disk) === "refused";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: refused ? "disk is-refused" : "disk",
		"aria-pressed": pressed,
		onClick: onSelect,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col gap-1 sm:grid sm:grid-cols-5 sm:items-center sm:gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-semibold",
					children: ["PhysicalDrive", disk.number]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: disk.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.floor(disk.size / 1048576), " MB"] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					disk.vid,
					":",
					disk.pid
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: verdict(disk) === "large" ? "text-warn" : void 0,
					children: t(lang, statusKey(disk))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-xs text-muted",
			children: fp
		})]
	});
}
function Confirm({ lang, disk, fp, checked, typed, ready, onChecked, onTyped, onCancel, onOk }) {
	const label = `PhysicalDrive${disk.number}`;
	const vidpid = `${disk.vid}:${disk.pid}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		id: "dialog-title",
		className: "bg-danger px-4 py-4 text-lg font-bold text-danger-ink",
		children: t(lang, "confirm.warning")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-danger",
				children: t(lang, "warning.usb_all")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed",
				children: [
					t(lang, "confirm.disk", label),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					t(lang, "confirm.name", disk.name),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					t(lang, "confirm.size", Math.floor(disk.size / 1048576)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					t(lang, "confirm.vidpid", vidpid),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					t(lang, "confirm.fp", fp)
				]
			}),
			verdict(disk) === "large" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-warn",
				children: t(lang, "warn.large")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "preview.confirm_note")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					id: "confirm-check",
					checked,
					onCheckedChange: (v) => onChecked(v === true),
					className: "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded border border-line bg-bg",
					"data-testid": "confirm-check",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						"aria-hidden": "true",
						size: 16
					}) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "confirm-check",
					children: t(lang, "confirm.checkbox")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-2 text-sm",
				children: [t(lang, "confirm.typetext", label), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					"data-testid": "confirm-type",
					value: typed,
					autoComplete: "off",
					spellCheck: false,
					onChange: (e) => onTyped(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-danger",
					"data-testid": "confirm-ok",
					disabled: !ready,
					onClick: onOk,
					children: t(lang, "confirm.proceed")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onCancel,
					children: t(lang, "confirm.no")
				})]
			})
		]
	})] });
}
//#endregion
export { Home as component };
