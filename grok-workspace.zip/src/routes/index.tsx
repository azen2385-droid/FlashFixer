import { createFileRoute } from "@tanstack/react-router";
import * as Checkbox from "@radix-ui/react-checkbox";
import { Check, Download, RefreshCw, ShieldAlert, Usb } from "lucide-react";
import { useEffect, useState } from "react";
import {
  DEMO_DISKS,
  LANGS,
  SKINS,
  fingerprint,
  statusKey,
  t,
  verdict,
  type DemoDisk,
  type Lang,
  type Skin,
  type UiMode,
} from "@/lib/copy";

export const Route = createFileRoute("/")({ component: Home });

type Phase = "list" | "confirm" | "uac" | "done" | "denied";

function Home() {
  const [lang, setLang] = useState<Lang>("ar");
  const [selected, setSelected] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>("list");
  const [scanning, setScanning] = useState(false);
  const [checked, setChecked] = useState(false);
  const [typed, setTyped] = useState("");
  const [prints, setPrints] = useState<Record<number, string>>({});
  const [skin, setSkin] = useState<Skin>("basic");
  const [mode, setMode] = useState<UiMode>("night");
  const [lookReady, setLookReady] = useState(false);

  const rtl = lang === "ar";
  const disk = DEMO_DISKS.find((d) => d.number === selected) ?? null;
  const canRepair = disk != null && verdict(disk) !== "refused";
  const label = disk ? `PhysicalDrive${disk.number}` : "";
  const confirmReady = checked && typed.trim() === label;

  useEffect(() => {
    document.documentElement.dataset.skin = skin;
    document.documentElement.dataset.mode = mode;
    if (!lookReady) return;
    try {
      localStorage.setItem("ff-ui", JSON.stringify({ skin, mode }));
    } catch {
      /* preview storage can be blocked */
    }
  }, [skin, mode, lookReady]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("ff-ui");
      if (raw) {
        const saved = JSON.parse(raw) as { skin?: Skin; mode?: UiMode };
        if (saved.skin && SKINS.some((item) => item.id === saved.skin)) setSkin(saved.skin);
        if (saved.mode === "night" || saved.mode === "day") setMode(saved.mode);
      }
    } catch {
      /* ignore broken saved look */
    }
    setLookReady(true);
  }, []);

  useEffect(() => {
    let cancelled = false;
    Promise.all(DEMO_DISKS.map(async (d) => [d.number, await fingerprint(d)] as const)).then(
      (rows) => {
        if (cancelled) return;
        const next: Record<number, string> = {};
        for (const [n, fp] of rows) next[n] = fp;
        setPrints(next);
      },
    );
    return () => {
      cancelled = true;
    };
  }, []);

  function refresh() {
    setScanning(true);
    setSelected(null);
    window.setTimeout(() => setScanning(false), 700);
  }

  function openRepair() {
    if (!canRepair) return;
    setChecked(false);
    setTyped("");
    setPhase("confirm");
  }

  return (
    <main dir={rtl ? "rtl" : "ltr"} lang={lang} className="stage min-h-screen bg-bg text-fg">
      <Atmosphere />
      <p className="bg-danger px-4 py-3 text-center text-sm font-semibold text-danger-ink">
        {t(lang, "preview.banner")}
      </p>

      <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-5">
        <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-lg bg-danger text-danger-ink">
              <Usb aria-hidden="true" />
            </span>
            <h1 className="text-2xl font-bold leading-tight">{t(lang, "app.title")}</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            {LANGS.map((item) => (
              <button
                key={item.id}
                type="button"
                className="lang-btn"
                aria-pressed={lang === item.id}
                onClick={() => setLang(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </header>

        <div className="panel flex flex-col gap-3 p-3">
          <p className="text-xs font-semibold text-muted">{t(lang, "ui.look")}</p>
          <div className="flex flex-wrap gap-2">
            {SKINS.map((item) => (
              <button
                key={item.id}
                type="button"
                className="lang-btn"
                aria-pressed={skin === item.id}
                onClick={() => setSkin(item.id)}
              >
                <span className={`swatch ${item.swatch}`} aria-hidden="true" />
                {t(lang, `skin.${item.id}`)}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" className="lang-btn" aria-pressed={mode === "night"} onClick={() => setMode("night")}>
              {t(lang, "mode.night")}
            </button>
            <button type="button" className="lang-btn" aria-pressed={mode === "day"} onClick={() => setMode("day")}>
              {t(lang, "mode.day")}
            </button>
          </div>
        </div>

        <section className="panel overflow-hidden">
          <p className="bg-danger px-4 py-3 text-sm font-semibold text-danger-ink">
            {t(lang, "warning.usb_all")}
          </p>
          <div className="flex flex-col gap-2 p-3 sm:flex-row">
            <button type="button" className="btn" onClick={refresh} disabled={scanning}>
              <RefreshCw aria-hidden="true" size={18} />
              {t(lang, "list.refresh")}
            </button>
            <button
              type="button"
              className="btn btn-danger"
              data-testid="repair"
              disabled={!canRepair || scanning}
              onClick={openRepair}
            >
              <ShieldAlert aria-hidden="true" size={18} />
              {t(lang, "btn.repair")}
            </button>
          </div>
          <p className="px-4 pb-2 text-sm text-muted">{t(lang, "preview.sim")}</p>
          <div className="hidden grid-cols-5 gap-2 px-4 pb-2 text-xs font-semibold text-muted sm:grid">
            <span>{t(lang, "col.num")}</span>
            <span>{t(lang, "col.name")}</span>
            <span>{t(lang, "col.size")}</span>
            <span>{t(lang, "col.vidpid")}</span>
            <span>{t(lang, "col.status")}</span>
          </div>
          {scanning ? (
            <p className="px-4 py-8 text-muted">{t(lang, "status.scanning")}</p>
          ) : (
            <div>
              {DEMO_DISKS.map((item) => (
                <DiskRow
                  key={item.number}
                  lang={lang}
                  disk={item}
                  fp={prints[item.number] ?? "…"}
                  pressed={selected === item.number}
                  onSelect={() => setSelected(item.number)}
                />
              ))}
            </div>
          )}
          <p className="border-t border-line px-4 py-3 text-sm text-muted">
            {scanning ? t(lang, "status.scanning") : t(lang, "list.count", DEMO_DISKS.length)}
          </p>
        </section>

        <section className="panel flex flex-col gap-3 p-4">
          <p className="text-sm leading-relaxed text-muted">{t(lang, "preview.compat")}</p>
          <p className="text-sm leading-relaxed text-warn">{t(lang, "preview.xp")}</p>
          <a className="btn w-full sm:w-fit" href="/FlashFixer-src.zip" download>
            <Download aria-hidden="true" size={18} />
            {t(lang, "preview.download")}
          </a>
        </section>
      </div>

      {phase !== "list" && disk ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-bg/80 p-3 sm:items-center">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="dialog-title"
            className="panel max-h-[92vh] w-full max-w-lg overflow-y-auto"
          >
            {phase === "confirm" ? (
              <Confirm
                lang={lang}
                disk={disk}
                fp={prints[disk.number] ?? "…"}
                checked={checked}
                typed={typed}
                ready={confirmReady}
                onChecked={setChecked}
                onTyped={setTyped}
                onCancel={() => setPhase("list")}
                onOk={() => setPhase("uac")}
              />
            ) : null}
            {phase === "uac" ? (
              <div className="flex flex-col gap-4 p-4">
                <h2 id="dialog-title" className="text-xl font-bold">
                  {t(lang, "preview.uac_title")}
                </h2>
                <p className="text-sm text-muted">{t(lang, "preview.uac_body")}</p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <button type="button" className="btn btn-danger" data-testid="uac-allow" onClick={() => setPhase("done")}>
                    {t(lang, "preview.allow")}
                  </button>
                  <button type="button" className="btn" data-testid="uac-deny" onClick={() => setPhase("denied")}>
                    {t(lang, "preview.deny")}
                  </button>
                </div>
              </div>
            ) : null}
            {phase === "done" || phase === "denied" ? (
              <div className="flex flex-col gap-4 p-4">
                <h2 id="dialog-title" className="text-xl font-bold">
                  {phase === "done" ? t(lang, "preview.result_title") : t(lang, "uac.cancelled")}
                </h2>
                <p className="text-sm leading-relaxed">
                  {phase === "done" ? t(lang, "preview.result_body") : t(lang, "preview.banner")}
                </p>
                {phase === "done" ? (
                  <p className="panel bg-surface-2 px-3 py-3 text-sm">
                    <span className="block text-muted">{t(lang, "preview.real_says")}</span>
                    {t(lang, "worker.done")}
                  </p>
                ) : null}
                <button type="button" className="btn" onClick={() => setPhase("list")}>
                  {t(lang, "preview.close")}
                </button>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}
    </main>
  );
}

function Atmosphere() {
  return (
    <div className="atmos" aria-hidden="true">
      <div className="breath" />
      <div className="core" />
      <div className="scan" />
      <div className="embers">
        {Array.from({ length: 10 }, (_, i) => (
          <i key={i} />
        ))}
      </div>
      <div className="waves">
        <i />
        <i />
        <i />
      </div>
      <div className="stars">
        {Array.from({ length: 12 }, (_, i) => (
          <i key={i} />
        ))}
      </div>
    </div>
  );
}

function DiskRow({
  lang,
  disk,
  fp,
  pressed,
  onSelect,
}: {
  lang: Lang;
  disk: DemoDisk;
  fp: string;
  pressed: boolean;
  onSelect: () => void;
}) {
  const refused = verdict(disk) === "refused";
  return (
    <button
      type="button"
      className={refused ? "disk is-refused" : "disk"}
      aria-pressed={pressed}
      onClick={onSelect}
    >
      <span className="flex flex-col gap-1 sm:grid sm:grid-cols-5 sm:items-center sm:gap-2">
        <span className="font-semibold">PhysicalDrive{disk.number}</span>
        <span>{disk.name}</span>
        <span>{Math.floor(disk.size / 1048576)} MB</span>
        <span>
          {disk.vid}:{disk.pid}
        </span>
        <span className={verdict(disk) === "large" ? "text-warn" : undefined}>{t(lang, statusKey(disk))}</span>
      </span>
      <span className="mt-1 block text-xs text-muted">{fp}</span>
    </button>
  );
}

function Confirm({
  lang,
  disk,
  fp,
  checked,
  typed,
  ready,
  onChecked,
  onTyped,
  onCancel,
  onOk,
}: {
  lang: Lang;
  disk: DemoDisk;
  fp: string;
  checked: boolean;
  typed: string;
  ready: boolean;
  onChecked: (v: boolean) => void;
  onTyped: (v: string) => void;
  onCancel: () => void;
  onOk: () => void;
}) {
  const label = `PhysicalDrive${disk.number}`;
  const vidpid = `${disk.vid}:${disk.pid}`;
  return (
    <div>
      <h2 id="dialog-title" className="bg-danger px-4 py-4 text-lg font-bold text-danger-ink">
        {t(lang, "confirm.warning")}
      </h2>
      <div className="flex flex-col gap-3 p-4">
        <p className="text-sm font-semibold text-danger">{t(lang, "warning.usb_all")}</p>
        <p className="text-sm leading-relaxed">
          {t(lang, "confirm.disk", label)}
          <br />
          {t(lang, "confirm.name", disk.name)}
          <br />
          {t(lang, "confirm.size", Math.floor(disk.size / 1048576))}
          <br />
          {t(lang, "confirm.vidpid", vidpid)}
          <br />
          {t(lang, "confirm.fp", fp)}
        </p>
        {verdict(disk) === "large" ? <p className="text-sm font-semibold text-warn">{t(lang, "warn.large")}</p> : null}
        <p className="text-sm text-muted">{t(lang, "preview.confirm_note")}</p>
        <div className="flex items-start gap-3 text-sm">
          <Checkbox.Root
            id="confirm-check"
            checked={checked}
            onCheckedChange={(v) => onChecked(v === true)}
            className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded border border-line bg-bg"
            data-testid="confirm-check"
          >
            <Checkbox.Indicator>
              <Check aria-hidden="true" size={16} />
            </Checkbox.Indicator>
          </Checkbox.Root>
          <label htmlFor="confirm-check">{t(lang, "confirm.checkbox")}</label>
        </div>
        <label className="flex flex-col gap-2 text-sm">
          {t(lang, "confirm.typetext", label)}
          <input
            className="field"
            data-testid="confirm-type"
            value={typed}
            autoComplete="off"
            spellCheck={false}
            onChange={(e) => onTyped(e.target.value)}
          />
        </label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button type="button" className="btn btn-danger" data-testid="confirm-ok" disabled={!ready} onClick={onOk}>
            {t(lang, "confirm.proceed")}
          </button>
          <button type="button" className="btn" onClick={onCancel}>
            {t(lang, "confirm.no")}
          </button>
        </div>
      </div>
    </div>
  );
}
