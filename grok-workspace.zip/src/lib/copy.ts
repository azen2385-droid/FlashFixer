export type Lang = "ar" | "en" | "zh" | "fr";
export type Skin = "basic" | "fire" | "water" | "sky" | "dynamic";
export type UiMode = "night" | "day";

export const LANGS: { id: Lang; label: string }[] = [
  { id: "ar", label: "عربي" },
  { id: "en", label: "EN" },
  { id: "zh", label: "中文" },
  { id: "fr", label: "FR" },
];

export const SKINS: { id: Skin; swatch: string }[] = [
  { id: "basic", swatch: "swatch-basic" },
  { id: "fire", swatch: "swatch-fire" },
  { id: "water", swatch: "swatch-water" },
  { id: "sky", swatch: "swatch-sky" },
  { id: "dynamic", swatch: "swatch-dynamic" },
];

const copy: Record<Lang, Record<string, string>> = {
  ar: {
    "app.title": "مصلح الفلاشات",
    "list.none": "مفيش فلاشات USB",
    "list.refresh": "تحديث",
    "list.count": "{0} فلاشة USB",
    "btn.repair": "فحص وإصلاح",
    "col.num": "القرص",
    "col.name": "الاسم",
    "col.size": "الحجم",
    "col.vidpid": "VID:PID",
    "col.status": "الحالة",
    "status.ready": "جاهز",
    "status.scanning": "جاري الفحص...",
    "warning.usb_all":
      "تحذير مهم: أي جهاز متوصل بـ USB هيظهر هنا (بما فيه الهاردات الخارجية). افصل أي هارد ديسك خارجي مش عايز تمسحه.",
    "confirm.title": "تأكيد الإصلاح",
    "confirm.warning": "كل البيانات على القرص ده هتتمسح.",
    "confirm.disk": "القرص: {0}",
    "confirm.name": "الاسم: {0}",
    "confirm.size": "الحجم: {0} ميجا",
    "confirm.vidpid": "VID:PID: {0}",
    "confirm.fp": "البصمة: {0}",
    "confirm.checkbox": "أنا فاهم إن كل البيانات على القرص ده هتضيع",
    "confirm.typetext": "اكتب \"{0}\" للتأكيد:",
    "confirm.proceed": "امسح وأصلح",
    "confirm.no": "إلغاء",
    "refuse.no_media": "مرفوض: مفيش وسيط",
    "warn.large": "تحذير: القرص أكبر من 256 جيجا. محتاج تأكيد إضافي.",
    "worker.done": "الإصلاح خلص بنجاح.",
    "uac.cancelled": "صلاحية المدير اترفضت.",
    "preview.banner": "معاينة للشكل بس. المتصفح مش شايف فلاشاتك، ومفيش أي مسح بيحصل من هنا.",
    "preview.sim": "أقراص تجريبية عشان تراجع الشاشة قبل ما تبني البرنامج على ويندوز.",
    "preview.download": "تنزيل كود برنامج الويندوز",
    "preview.compat":
      "النسخة الحقيقية: ملف واحد من ويندوز 7 SP1 لحد 11، 32 و 64 بت، من غير تثبيت. لازم .NET Framework 4.8.",
    "preview.xp":
      "ويندوز XP مش مدعوم. أدوات حماية قرص النظام وكشف الـ USB مش موجودة عليه، فنسخة أضعف تبقى خطر.",
    "preview.confirm_note": "الكتابة هنا تجربة للشاشة. مش هتتمسح أي حاجة.",
    "preview.uac_title": "صلاحية المدير",
    "preview.uac_body": "على الويندوز بتظهر نافذة UAC هنا. الزرارين دول تجريبيين.",
    "preview.allow": "موافقة",
    "preview.deny": "رفض",
    "preview.result_title": "المعاينة خلصت",
    "preview.result_body":
      "مفيش أي بيانات اتمسحت. في البرنامج الحقيقي، بعد التأكيد ده، diskpart هو اللي بيمسح الفلاشة اللي اتأكدنا من بصمتها.",
    "preview.real_says": "البرنامج الحقيقي هيقول:",
    "preview.close": "تمام",
    "skin.basic": "أساسي",
    "skin.fire": "ناري",
    "skin.water": "مائي",
    "skin.sky": "سماوي",
    "skin.dynamic": "ديناميكي",
    "mode.night": "ليل",
    "mode.day": "نهار",
    "ui.look": "الشكل",
  },
  en: {
    "app.title": "Flash Fixer",
    "list.none": "No USB flash drives found",
    "list.refresh": "Refresh",
    "list.count": "{0} USB disk(s)",
    "btn.repair": "Scan & Repair",
    "col.num": "Disk",
    "col.name": "Name",
    "col.size": "Size",
    "col.vidpid": "VID:PID",
    "col.status": "Status",
    "status.ready": "Ready",
    "status.scanning": "Scanning...",
    "warning.usb_all":
      "WARNING: Any USB-connected drive will appear here (including external HDDs). Disconnect any external hard drive you do not want to risk erasing.",
    "confirm.title": "Confirm Repair",
    "confirm.warning": "ALL DATA on this drive will be erased.",
    "confirm.disk": "Disk: {0}",
    "confirm.name": "Name: {0}",
    "confirm.size": "Size: {0} MB",
    "confirm.vidpid": "VID:PID: {0}",
    "confirm.fp": "Fingerprint: {0}",
    "confirm.checkbox": "I understand that all data on this drive will be lost",
    "confirm.typetext": "Type \"{0}\" to confirm:",
    "confirm.proceed": "Erase and repair",
    "confirm.no": "Cancel",
    "refuse.no_media": "Refused: No media",
    "warn.large": "Warning: disk larger than 256 GB. Extra confirmation required.",
    "worker.done": "Repair completed successfully.",
    "uac.cancelled": "Administrator permission was declined.",
    "preview.banner": "Layout preview only. This browser cannot see your drives, and nothing is erased here.",
    "preview.sim": "Sample disks, so you can review the screen before building the Windows program.",
    "preview.download": "Download the Windows source",
    "preview.compat":
      "The real build is one EXE for Windows 7 SP1 through 11, 32 and 64-bit, with no installer. It needs .NET Framework 4.8.",
    "preview.xp":
      "Windows XP is not supported. The system-disk guard and USB bus check do not exist there, so a weaker build would be a risk.",
    "preview.confirm_note": "Typing here only tests the screen. Nothing will be erased.",
    "preview.uac_title": "Administrator permission",
    "preview.uac_body": "On Windows, UAC appears here. These two buttons are only a preview.",
    "preview.allow": "Allow",
    "preview.deny": "Deny",
    "preview.result_title": "Preview finished",
    "preview.result_body":
      "No data was erased. In the real program, diskpart wipes only the drive whose fingerprint was just checked.",
    "preview.real_says": "The real program would say:",
    "preview.close": "Done",
    "skin.basic": "Basic",
    "skin.fire": "Fire",
    "skin.water": "Water",
    "skin.sky": "Sky",
    "skin.dynamic": "Dynamic",
    "mode.night": "Night",
    "mode.day": "Day",
    "ui.look": "Look",
  },
  zh: {
    "app.title": "U盘修复工具",
    "list.none": "未找到 USB 闪存盘",
    "list.refresh": "刷新",
    "list.count": "{0} 个 USB 磁盘",
    "btn.repair": "扫描并修复",
    "col.num": "磁盘",
    "col.name": "名称",
    "col.size": "大小",
    "col.vidpid": "VID:PID",
    "col.status": "状态",
    "status.ready": "就绪",
    "status.scanning": "正在扫描...",
    "warning.usb_all":
      "警告：所有通过 USB 连接的磁盘都会显示在此（包括外接硬盘）。请先断开您不希望被擦除的外接硬盘。",
    "confirm.title": "确认修复",
    "confirm.warning": "此驱动器上的所有数据将被擦除。",
    "confirm.disk": "磁盘：{0}",
    "confirm.name": "名称：{0}",
    "confirm.size": "大小：{0} MB",
    "confirm.vidpid": "VID:PID：{0}",
    "confirm.fp": "指纹：{0}",
    "confirm.checkbox": "我明白此驱动器上的所有数据都将丢失",
    "confirm.typetext": "输入\"{0}\"以确认：",
    "confirm.proceed": "擦除并修复",
    "confirm.no": "取消",
    "refuse.no_media": "已拒绝：无介质",
    "warn.large": "警告：磁盘大于 256 GB。需要额外确认。",
    "worker.done": "修复成功完成。",
    "uac.cancelled": "管理员权限被拒绝。",
    "preview.banner": "这只是界面预览。浏览器看不到您的磁盘，这里不会擦除任何数据。",
    "preview.sim": "以下是示例磁盘，方便您在 Windows 上编译前先看屏幕。",
    "preview.download": "下载 Windows 源码",
    "preview.compat": "正式版是一个 EXE，支持 Windows 7 SP1 到 11（32 位和 64 位），无需安装。需要 .NET Framework 4.8。",
    "preview.xp": "不支持 Windows XP。系统盘保护和 USB 总线检测在 XP 上不存在，弱化版本会有风险。",
    "preview.confirm_note": "在这里输入只是在试界面，不会擦除任何内容。",
    "preview.uac_title": "管理员权限",
    "preview.uac_body": "在 Windows 上，这里会弹出 UAC。这两个按钮只是预览。",
    "preview.allow": "允许",
    "preview.deny": "拒绝",
    "preview.result_title": "预览结束",
    "preview.result_body": "没有擦除任何数据。真正的程序会用 diskpart，并且只处理刚刚核对过指纹的那块盘。",
    "preview.real_says": "正式程序会显示：",
    "preview.close": "完成",
    "skin.basic": "基础",
    "skin.fire": "火焰",
    "skin.water": "水流",
    "skin.sky": "天空",
    "skin.dynamic": "动态",
    "mode.night": "夜间",
    "mode.day": "日间",
    "ui.look": "外观",
  },
  fr: {
    "app.title": "Réparateur de clés USB",
    "list.none": "Aucune clé USB trouvée",
    "list.refresh": "Rafraîchir",
    "list.count": "{0} disque(s) USB",
    "btn.repair": "Analyser et réparer",
    "col.num": "Disque",
    "col.name": "Nom",
    "col.size": "Taille",
    "col.vidpid": "VID:PID",
    "col.status": "État",
    "status.ready": "Prêt",
    "status.scanning": "Analyse...",
    "warning.usb_all":
      "AVERTISSEMENT : tout disque connecté en USB apparaîtra ici (y compris les disques externes). Débranchez tout disque externe que vous ne voulez pas risquer d'effacer.",
    "confirm.title": "Confirmer la réparation",
    "confirm.warning": "TOUTES LES DONNÉES de ce disque seront effacées.",
    "confirm.disk": "Disque : {0}",
    "confirm.name": "Nom : {0}",
    "confirm.size": "Taille : {0} Mo",
    "confirm.vidpid": "VID:PID : {0}",
    "confirm.fp": "Empreinte : {0}",
    "confirm.checkbox": "Je comprends que toutes les données de ce disque seront perdues",
    "confirm.typetext": "Tapez « {0} » pour confirmer :",
    "confirm.proceed": "Effacer et réparer",
    "confirm.no": "Annuler",
    "refuse.no_media": "Refusé : aucun média",
    "warn.large": "Attention : disque supérieur à 256 Go. Confirmation supplémentaire requise.",
    "worker.done": "Réparation terminée avec succès.",
    "uac.cancelled": "Autorisation administrateur refusée.",
    "preview.banner":
      "Aperçu seulement. Le navigateur ne voit pas vos disques, et rien n'est effacé ici.",
    "preview.sim": "Disques d'exemple, pour relire l'écran avant de compiler le programme Windows.",
    "preview.download": "Télécharger le code Windows",
    "preview.compat":
      "La vraie version est un EXE pour Windows 7 SP1 à 11, 32 et 64 bits, sans installation. .NET Framework 4.8 est requis.",
    "preview.xp":
      "Windows XP n'est pas pris en charge. La protection du disque système et le contrôle USB n'y existent pas.",
    "preview.confirm_note": "La saisie ici ne fait que tester l'écran. Rien ne sera effacé.",
    "preview.uac_title": "Autorisation administrateur",
    "preview.uac_body": "Sous Windows, l'UAC s'affiche ici. Ces deux boutons sont une prévisualisation.",
    "preview.allow": "Autoriser",
    "preview.deny": "Refuser",
    "preview.result_title": "Aperçu terminé",
    "preview.result_body":
      "Aucune donnée n'a été effacée. Le vrai programme lance diskpart uniquement sur le disque dont l'empreinte vient d'être vérifiée.",
    "preview.real_says": "Le vrai programme afficherait :",
    "preview.close": "Fermer",
    "skin.basic": "Sobre",
    "skin.fire": "Feu",
    "skin.water": "Eau",
    "skin.sky": "Ciel",
    "skin.dynamic": "Dynamique",
    "mode.night": "Nuit",
    "mode.day": "Jour",
    "ui.look": "Style",
  },
};

export function t(lang: Lang, key: string, ...args: Array<string | number>): string {
  const table = copy[lang];
  let s = table[key] ?? copy.en[key] ?? key;
  args.forEach((arg, i) => {
    s = s.split(`{${i}}`).join(String(arg));
  });
  return s;
}

export type DemoDisk = {
  number: number;
  name: string;
  size: number;
  vid: string;
  pid: string;
};

export const DEMO_DISKS: DemoDisk[] = [
  { number: 2, name: "Kingston DataTraveler 3.0", size: 15548024832, vid: "0951", pid: "1666" },
  { number: 4, name: "SanDisk Ultra", size: 61847529062, vid: "0781", pid: "5581" },
  { number: 5, name: "Seagate Expansion", size: 4000787030016, vid: "0BC2", pid: "231A" },
  { number: 6, name: "Generic Card Reader", size: 0, vid: "058F", pid: "6366" },
];

const LARGE = 256 * 1024 * 1024 * 1024;

export function verdict(disk: DemoDisk): "ok" | "large" | "refused" {
  if (disk.size <= 0) return "refused";
  if (disk.size > LARGE) return "large";
  return "ok";
}

export function statusKey(disk: DemoDisk): string {
  const v = verdict(disk);
  if (v === "refused") return "refuse.no_media";
  if (v === "large") return "warn.large";
  return "status.ready";
}

export async function fingerprint(disk: DemoDisk): Promise<string> {
  const raw = `${disk.size}|${disk.vid}:${disk.pid}`;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
  const bytes = new Uint8Array(digest).slice(0, 8);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}
